﻿using System;
using System.Net;
using TechTalk.SpecFlow;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using TechTalk.SpecFlow.Assist;
using System.Threading;
using SpecflowTest003.Helper;

namespace SpecflowTest003
{
    [Binding]
    public class Profilestep
    {
        Loginpage profile_page = null;
        [Given(@"Login success")]
        [Given(@"Login for profile success")]
        public void GivenLoginForProfileSuccess()
        {
            IWebDriver web_driver = new ChromeDriver();
            //opening page
            web_driver.Navigate().GoToUrl("http://192.168.99.100:5000/");
            profile_page = new Loginpage(web_driver);
            Thread.Sleep(4000);
            profile_page.ClickSignin();
            profile_page.EnterLoginInform();
            profile_page.ClickLoginButton();
            Thread.Sleep(1000);
        }
                
        [Given(@"Click profile tab")]
        public void GivenClickProfileTab()
        {
            profile_page.ProfileTab();
        }
        
        [Given(@"Click description button")]
        public void GivenClickDescriptionButton()
        {
            Thread.Sleep(1000);
            profile_page.DescripBut();
        }
        
        [Given(@"Enter description text")]
        public void GivenEnterDescriptionText()
        {
            profile_page.DescripWord();
        }
        
        [When(@"Click save button")]
        public void WhenClickSaveButton()
        {
            profile_page.SaveBut();
        }
        
        [Then(@"See the discription")]
        public void ThenSeeTheDiscription()
        {
            Thread.Sleep(1000);
            Assert.That(profile_page.IfProfileSuccess(), Is.True);
            bool loginresult = profile_page.IfLoginSuccess();
            if (loginresult == true)
                ExcelHelper.EnterPass(2, 3);
            profile_page.Webquit();
        }
    }
}
