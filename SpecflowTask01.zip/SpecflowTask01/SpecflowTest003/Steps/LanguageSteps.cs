﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using System.Threading;
using SpecflowTest003.Helper;

namespace SpecflowTest003.Steps
{
    [Binding]
    public class LanguageSteps
    {
        Loginpage language_page = null;
        [Given(@"Login for language success")]
        public void GivenLoginForLanguageSuccess()
        {
            IWebDriver web_driver = new ChromeDriver();
            //opening page
            web_driver.Navigate().GoToUrl("http://192.168.99.100:5000/");
            language_page = new Loginpage(web_driver);
            Thread.Sleep(1000);
            language_page.ClickSignin();
            language_page.EnterLoginInform();
            Thread.Sleep(1000);
            language_page.ClickLoginButton();
            Thread.Sleep(1000);

        }
        
        [Given(@"Click language tab")]
        public void GivenClickLanguageTab()
        {
            language_page.ProfileTab();
            Thread.Sleep(500);
            language_page.ClickLangugeTab();
        }
        
        [Given(@"Click add new tab")]
        public void GivenClickAddNewTab()
        {
            language_page.LanguageAddNew();
        }
        
        [Given(@"Enter first language")]
        public void GivenEnterFirstLanguage()
        {
            language_page.EnterLanguage();
        }
        
        [Given(@"Choose language level")]
        public void GivenChooseLanguageLevel()
        {
            language_page.ChooseLevel();
        }
        
        [When(@"Click add button")]
        public void WhenClickAddButton()
        {
            language_page.ClickLanguageAddBut();
        }
        
        [Then(@"See the language")]
        public void ThenSeeTheLanguage()
        {
            Thread.Sleep(500);
            Assert.That(language_page.IfLanguageSuccess(), Is.True);
            Assert.That(language_page.IfLanglevelSuccess(), Is.True);
            bool language = language_page.IfLanguageSuccess();
            bool langlevel = language_page.IfLanguageSuccess();
            if (language == true && langlevel == true)
                ExcelHelper.EnterPass(3, 3);
            language_page.DeleteLanguage();
            language_page.Webquit();
        }
    }
}
