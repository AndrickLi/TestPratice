﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;
using System.Threading;
using SpecflowTest003.Helper;

namespace SpecflowTest003
{
    [Binding]
    public class Loginstep
    {
       public static Loginpage login_page = null;

        [Given(@"Launch the website")]
        public void GivenLaunchTheWebsite()
        {
            IWebDriver web_driver = new ChromeDriver();
            //opening page
            web_driver.Navigate().GoToUrl("http://192.168.99.100:5000/");
            login_page = new Loginpage(web_driver);
            //Thread.Sleep(4000);

        }

        [Given(@"Click Sigin Button")]
        public void GivenClickSiginButton()
        {
            login_page.ClickSignin();
        }
        
        [Given(@"Enter user name and password")]
        public void GivenEnterUserNameAndPassword()
        {
            //dynamic data = table.CreateDynamicInstance();
            //login_page.EnterLoginInform((string)data.UserEmail, (string)data.UserPassword);
            login_page.EnterLoginInform();
        }

        [When(@"Click login button")]
        public void WhenClickLoginButton()
        {
            login_page.ClickLoginButton();
        }

        [Then(@"See the user name")]
        public void ThenSeeTheUserName()
        {
            Thread.Sleep(1000);
            Assert.That(login_page.IfLoginSuccess(), Is.True);
            ScreenShoot.SaveScreenshot(login_page, "Login");
            bool loginresult = login_page.IfLoginSuccess();
            if (loginresult == true)
                ExcelHelper.EnterPass(1, 3);
            login_page.Webquit();
        }
    }
}
