﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using OpenQA.Selenium.Chrome;
using SpecflowTest003.Helper;
using OpenQA.Selenium.Support.UI;


namespace SpecflowTest003
{
    public class Loginpage
    {
        private IWebDriver web_driver;
        public Loginpage(IWebDriver webdrivertest)
        {
            web_driver = webdrivertest;
        }

        ////////////////////////////////////////////Login////////////////////

        //Signin button
        //public void ClickSignin() => sigin_button.Click();
        public IWebElement sigin_button => web_driver.FindElement(By.LinkText("Sign In"));
        public void ClickSignin()
        {
            sigin_button.Click();
        }
        //Email Address
        //IWebElement user_email = webdriver.FindElement(By.Name("UserName"));
        public IWebElement user_email => web_driver.FindElement(By.Name("email"));
        //Password
        public IWebElement user_password => web_driver.FindElement(By.Name("password"));
        public void EnterLoginInform()
        {
            user_email.SendKeys(ExcelHelper.ReadData(1,4));
            user_password.SendKeys(ExcelHelper.ReadData(1,6));
        }
        //Login button
        public IWebElement login_button => web_driver.FindElement(By.XPath("//button[@class='fluid ui teal button']"));
        public void ClickLoginButton()
        {
            login_button.Click();
        }
        //Verify
        public IWebElement login_success => web_driver.FindElement(By.LinkText("Profile"));       
        public bool IfLoginSuccess() => login_success.Displayed;
        //String text = web_driver.getText();


        //////////////////////////////////////Profile/////////////////////////        
        //Profile tab
        public IWebElement profile_tab  => web_driver.FindElement(By.LinkText("Profile"));
        
        public void ProfileTab()
        {
            profile_tab.Click();
        }

        //Description button
        public IWebElement description_button => web_driver.FindElement(By.XPath("/html/body/div[1]/div/section[2]/div/div/div/div[3]/div/div/div/h3/span/i"));
        public void DescripBut()
        {
            description_button.Click();
        }

        //Description words
        public IWebElement description_words => web_driver.FindElement(By.XPath("/html/body/div[1]/div/section[2]/div/div/div/div[3]/div/div/form/div/div/div[2]/div[1]/textarea"));
        public void DescripWord()
        {
            Thread.Sleep(200);
            description_words.SendKeys(Keys.Control + 'a');
            Thread.Sleep(200);
            description_words.SendKeys(Keys.Delete);
            Thread.Sleep(200);
            description_words.SendKeys(ExcelHelper.ReadData(2, 4));
        }
        //Save Button
        public IWebElement save_button => web_driver.FindElement(By.XPath("/html/body/div[1]/div/section[2]/div/div/div/div[3]/div/div/form/div/div/div[2]/button"));
        public void SaveBut()
        {
            save_button.Click();
        }
        public IWebElement profile_success => web_driver.FindElement(By.XPath("//span[contains(.,'" + ExcelHelper.ReadData(2, 4) + "')]"));
        //ExcelHelper.ReadData(2, 4)
        public bool IfProfileSuccess() => profile_success.Displayed;

        /////////////////////////////////Language/////////////////////////
        //language_tab
        public IWebElement language_tab => web_driver.FindElement(By.XPath("/html[1]/body[1]/div[1]/div[1]/section[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/a[1]"));
        public void ClickLangugeTab()
        {
            language_tab.Click();
        }
        //language_addnew
        public IWebElement language_addnew => web_driver.FindElement(By.XPath("(//div[@class='ui teal button '][contains(.,'Add New')])[1]"));
        public void LanguageAddNew()
        {
            language_addnew.Click();
        }
        //Enter first language
        public IWebElement enter_language => web_driver.FindElement(By.XPath("//input[@placeholder='Add Language']"));
        public void EnterLanguage()
        {
            enter_language.SendKeys(ExcelHelper.ReadData(3, 4));
        }
        //Choose level
        public IWebElement choose_level => web_driver.FindElement(By.XPath("//select[@class='ui dropdown']"));
        public void ChooseLevel()
        {
            new SelectElement(choose_level).SelectByText(ExcelHelper.ReadData(3,6));
        }
        //Click add button
        public IWebElement click_add => web_driver.FindElement(By.XPath("//input[@class='ui teal button'][1]"));
        public void ClickLanguageAddBut()
        {
            click_add.Click();
        }
        //Language veryfiy
        public IWebElement language_success => web_driver.FindElement(By.XPath("//td[contains(.,'" + ExcelHelper.ReadData(3, 4) + "')]"));
        public IWebElement langlevel_success => web_driver.FindElement(By.XPath("//td[contains(.,'" + ExcelHelper.ReadData(3, 6) + "')]"));
        public bool IfLanguageSuccess() => language_success.Displayed;
        public bool IfLanglevelSuccess() => langlevel_success.Displayed;
        //Delete Language
        public IWebElement delete_language => web_driver.FindElement(By.XPath("(//i[@class='remove icon'])[1]"));
        public void  DeleteLanguage()
        {
            delete_language.Click();
        }
        ////////////quite
        public void Webquit()
        {
            web_driver.Quit();
        }

    }
}
