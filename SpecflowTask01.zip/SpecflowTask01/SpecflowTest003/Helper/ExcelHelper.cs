﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;
using NPOI.HSSF.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;

namespace SpecflowTest003.Helper
{
    class ExcelHelper
    {
        
        public static string ReadData(int ex_row, int ex_cell)
        {
            var dirdebug = AppDomain.CurrentDomain.BaseDirectory;
            string direxcel = dirdebug.Replace("bin\\Debug\\netcoreapp3.1\\", "TestCase\\case01.xlsx");
            XSSFWorkbook hssfwb;
            using (FileStream ex_file = new FileStream(direxcel, FileMode.Open, FileAccess.Read))
            {
                hssfwb = new XSSFWorkbook(ex_file);
            }
            ISheet ex_sheet = hssfwb.GetSheet("TestData");

            string ex_data = string.Format(ex_sheet.GetRow(ex_row).GetCell(ex_cell).StringCellValue);
            return ex_data;
        }
        public static string EnterPass(int ex_row, int ex_cell)
        {
            var dirdebug = AppDomain.CurrentDomain.BaseDirectory;
            string direxcel = dirdebug.Replace("bin\\Debug\\netcoreapp3.1\\", "TestCase\\case01.xlsx");
            XSSFWorkbook hssfwb;
            using (FileStream ex_file = new FileStream(direxcel, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                hssfwb = new XSSFWorkbook(ex_file);
            }
            ISheet ex_sheet = hssfwb.GetSheet("TestCase");
            ICell ex_data = ex_sheet.GetRow(ex_row).GetCell(ex_cell);
            ex_data.SetCellValue("Pass");
            //string ex_show = string.Format(ex_data.StringCellValue);
            //MessageBox.Show(ex_show);
            using (FileStream ex_file = new FileStream(direxcel, FileMode.Create, FileAccess.Write))
            {
                hssfwb.Write(ex_file);
            }
            hssfwb.Close();
            return null;
        }

    }
}
