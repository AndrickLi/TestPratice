﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;


namespace TestTask_02.Helper
{
    class SaveTestImage
    {
        public static void GetScreen(IWebDriver driver,  String ImageName)
        {
            var dirdebug = AppDomain.CurrentDomain.BaseDirectory;
            string dirimage = dirdebug.Replace("bin\\Debug\\netcoreapp3.1\\", "TesCase");
            Screenshot screenShotFile = ((ITakesScreenshot)driver).GetScreenshot();
            screenShotFile.SaveAsFile(dirimage +"\\"+ ImageName);
        }
    }
}
