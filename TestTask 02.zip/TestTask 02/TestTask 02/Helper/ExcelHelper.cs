﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;

namespace TestTask_02
{
    class ExcelHelper
    {
        //Test Data
        public static string Url = ExcelHelper.ReadData("Test Data", 1, 1);
        public static string Email = ExcelHelper.ReadData("Test Data", 2, 1);
        public static string Password = ExcelHelper.ReadData("Test Data", 3, 1);

        public static string Title = ExcelHelper.ReadData("Test Data", 5, 1);
        public static string Description = ExcelHelper.ReadData("Test Data", 6, 1);
        public static string Category = ExcelHelper.ReadData("Test Data", 7, 1);
        public static string Subcategory = ExcelHelper.ReadData("Test Data", 8, 1);
        public static string Tags = ExcelHelper.ReadData("Test Data", 9, 1);
        public static string ServiceType = ExcelHelper.ReadData("Test Data", 10, 1);
        public static string LocationType = ExcelHelper.ReadData("Test Data", 11, 1);
        public static string EndDate = ExcelHelper.ReadData("Test Data", 12, 1);
        public static string StartTime = ExcelHelper.ReadData("Test Data", 13, 1);
        public static string EndTime = ExcelHelper.ReadData("Test Data", 14, 1);
        public static string SkillTrade = ExcelHelper.ReadData("Test Data", 15, 1);
        public static string SkillCredit = ExcelHelper.ReadData("Test Data", 16, 1);

        //Test Result  Location
        public static int CaseResult_cell = 4;
        public static int CaseResult_row01 = 1;
        public static int CaseResult_row02 = 2;
        public static int CaseResult_row03 = 3;
        public static string ReadData(string ex_st, int ex_row, int ex_cell)
        {
            var dirdebug = AppDomain.CurrentDomain.BaseDirectory;
            string direxcel = dirdebug.Replace("bin\\Debug\\netcoreapp3.1\\", "TesCase\\TestCase.xlsx");
            XSSFWorkbook hssfwb;
            using (FileStream ex_file = new FileStream(direxcel, FileMode.Open, FileAccess.Read))
            {
                hssfwb = new XSSFWorkbook(ex_file);
            }
            ISheet ex_sheet = hssfwb.GetSheet(ex_st);

            string ex_data = string.Format(ex_sheet.GetRow(ex_row).GetCell(ex_cell).StringCellValue);
            return ex_data;
        }
        public static void EnterPass(int ex_row, int ex_cell)
        {
            var dirdebug = AppDomain.CurrentDomain.BaseDirectory;
            string direxcel = dirdebug.Replace("bin\\Debug\\netcoreapp3.1\\", "TesCase\\TestCase.xlsx");
            XSSFWorkbook hssfwb;
            using (FileStream ex_file = new FileStream(direxcel, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                hssfwb = new XSSFWorkbook(ex_file);
            }
            ISheet ex_sheet = hssfwb.GetSheet("Mars Test Conditions");
            ICell ex_data = ex_sheet.GetRow(ex_row).GetCell(ex_cell);
            ex_data.SetCellValue("Pass");
            //string ex_show = string.Format(ex_data.StringCellValue);
            //MessageBox.Show(ex_show);
            using (FileStream ex_file = new FileStream(direxcel, FileMode.Create, FileAccess.Write))
            {
                hssfwb.Write(ex_file);
            }
            hssfwb.Close();
        }
    }
}
