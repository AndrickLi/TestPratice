﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace TestTask_02
{
    class SkillDetail
    {
        public static IWebDriver EnterSkillDetail(IWebDriver driver)
        {
            //Skill Detail
            driver.FindElement(By.Name("title")).SendKeys(ExcelHelper.Title);
            driver.FindElement(By.Name("description")).SendKeys(ExcelHelper.Description);
            new SelectElement(driver.FindElement(By.Name("categoryId"))).SelectByValue(ExcelHelper.Category);
            new SelectElement(driver.FindElement(By.Name("subcategoryId"))).SelectByValue(ExcelHelper.Subcategory);

            driver.FindElement(By.XPath("(//input[contains(@class,'ReactTags__tagInputField')])[1]")).SendKeys(ExcelHelper.Tags + Keys.Enter);
            driver.FindElement(By.XPath("(//input[contains(@name,'serviceType')])['" + ExcelHelper.ServiceType + "']")).Click();

            driver.FindElement(By.XPath("(//input[contains(@name,'locationType')])['" + ExcelHelper.LocationType + "']")).Click();

            //Date
            driver.FindElement(By.Name("endDate")).SendKeys(ExcelHelper.EndDate);

            //Time
            driver.FindElement(By.XPath("(//input[contains(@tabindex,'0')])[5]")).Click();
            driver.FindElement(By.XPath("(//input[contains(@name,'StartTime')])[1]")).SendKeys(ExcelHelper.StartTime);
            driver.FindElement(By.XPath("(//input[contains(@name,'EndTime')])[1]")).SendKeys(ExcelHelper.EndTime);

            //driver.FindElement(By.XPath("(//input[contains(@tabindex,'0')])[11]")).Click();
            //driver.FindElement(By.XPath("(//input[contains(@name,'StartTime')])[7]")).SendKeys("15:00");
            //driver.FindElement(By.XPath("(//input[contains(@name,'EndTime')])[7]")).SendKeys("16:00");

            //Charge Credit
            driver.FindElement(By.XPath("(//input[contains(@name,'skillTrades')])['" + ExcelHelper.SkillTrade + "']")).Click();
            driver.FindElement(By.XPath("(//input[contains(@type,'text')])[4]")).SendKeys(ExcelHelper.SkillCredit + Keys.Enter);

            //isActive
            driver.FindElement(By.XPath("(//input[contains(@name,'isActive')])[1]")).Click();
            return null;
        }
        public static IWebDriver SaveSkillDetail(IWebDriver driver)
        {
            //Save
            driver.FindElement(By.XPath("(//input[contains(@type,'button')])[1]")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(30000);
            //Thread.Sleep(1000);
            //driver.FindElement(By.XPath("//td[@class='four wide'][contains(.,'Wood Working')]")).Click();
            return null;
        }



    }
}
