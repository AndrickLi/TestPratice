﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
using OpenQA.Selenium.Support.UI;

namespace TestTask_02
{
    class LoginPage
    {
        public static IWebDriver Login_Page(IWebDriver driver)
        {
            //IWebDriver driver = new ChromeDriver();
            //opening page
            //string Url = ExcelHelper.ReadData("Test Data", 1, 1);
            driver.Navigate().GoToUrl(ExcelHelper.Url);

            driver.Manage().Window.Maximize();
            //**Login**//
            //Find and click login button
            driver.FindElement(By.LinkText("Sign In")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(30000);

            //Enter Email
            driver.FindElement(By.Name("email")).SendKeys(ExcelHelper.Email);

            //Enter Password
            driver.FindElement(By.Name("password")).SendKeys(ExcelHelper.Password);

            //Click Login Button
            driver.FindElement(By.XPath("//button[@class='fluid ui teal button']")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(30000);
            return null;
        }
    }
}
