﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace TestTask_02
{
    class CheckDetail
    {
        //IWebDriver driver;
        public static bool CheckSkillDetail(IWebDriver driver)
        {

            bool check_result;
            bool Title = ExistsElement(driver, ExcelHelper.Title);
            bool Description = ExistsElement(driver, ExcelHelper.Description);
            bool Enddate = ExistsElement(driver, ExcelHelper.EndDate);
            if (Title && Description && Enddate == true)
                check_result = true;
            else
                check_result = false;
            return check_result;
        }
        private static bool ExistsElement(IWebDriver driver, String id)
        {
            try
            {
                driver.FindElement(By.XPath("//*[contains(text(),'" + id + "')]"));
            }
            catch (NoSuchElementException e)
            {
                return false;
            }
            return true;
        }


    }
}
