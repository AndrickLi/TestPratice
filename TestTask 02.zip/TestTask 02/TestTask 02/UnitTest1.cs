using NUnit.Framework;
using System;
using System.Drawing;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
using OpenQA.Selenium.Support.UI;
using TestTask_02.Helper;

namespace TestTask_02
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {


        }

        [Test]
        public void TestCase01()
        {
            // Creating an instance of driver/browser
            IWebDriver driver = new ChromeDriver();
            LoginPage.Login_Page(driver);

            driver.FindElement(By.LinkText("Share Skill")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(30000);
            try
            {
                var web_check = driver.FindElement(By.XPath("//*[contains(text(),'Title')]")).GetAttribute("innerText");
                Assert.That(web_check == "Title");
                if (web_check == "Title")
                {
                    ExcelHelper.EnterPass(ExcelHelper.CaseResult_row01, ExcelHelper.CaseResult_cell);
                }
            }
            catch (Exception)
            {
                throw;

            }
            finally
            {
                SaveTestImage.GetScreen(driver, "TestCase01.jpg");
                driver.Quit();
            }

        }

        [Test]
        public void TestCase02()
        {
            IWebDriver driver = new ChromeDriver();
            LoginPage.Login_Page(driver);
            driver.FindElement(By.LinkText("Share Skill")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(30000);
            SkillDetail.EnterSkillDetail(driver);
            SkillDetail.SaveSkillDetail(driver);

            try
            {
                var web_check = driver.FindElement(By.XPath("//*[contains(text(),'Wood Working')]")).GetAttribute("innerText");
                Assert.That(web_check == "Wood Working");
                if (web_check == "Wood Working")
                {
                    ExcelHelper.EnterPass(ExcelHelper.CaseResult_row02, ExcelHelper.CaseResult_cell);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                SaveTestImage.GetScreen(driver, "TestCase02.jpg");
                driver.Quit();
            }
        }
        [Test]
        public void TestCase03()
        {
            IWebDriver driver = new ChromeDriver();
            LoginPage.Login_Page(driver);
            driver.FindElement(By.XPath("//a[@class='item'][contains(.,'Manage Listings')]")).Click();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromMilliseconds(30000);
            driver.FindElement(By.XPath("(//i[contains(@class,'eye icon')])[1]")).Click();


            try
            {
                Assert.That(CheckDetail.CheckSkillDetail(driver));
                if(CheckDetail.CheckSkillDetail(driver) == true)
                {
                    ExcelHelper.EnterPass(ExcelHelper.CaseResult_row03, ExcelHelper.CaseResult_cell);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                SaveTestImage.GetScreen(driver, "TestCase03.jpg");
                driver.Quit();
            }

        }
    }
}